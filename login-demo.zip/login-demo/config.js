module.exports={
  "facebook_api_key"      :     "1751898518325434",
  "facebook_api_secret"   :     "",
  "callback_url"          :     "http://localhost:3000/auth/facebook/callback",
  "use_database"          :     true,
  "host"                  :     "localhost",
  "username"              :     "root",
  "password"              :     "",
  "database"              :     "login_passport"
}